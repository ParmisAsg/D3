// @TODO: YOUR CODE HERE!
//setting up width
var width = parseInt(d3.select("#scatter").style("width"));

//Height
var height = width - width / 4;

// Margin 
var margin = 20;

// space for placing words
var labelArea = 100;

// padding for the text at the bottom and left axes
var tPadBot = 40;
var tPadLeft = 40;

// Create the graph
var svg = d3
  .select("#scatter")
  .append("svg")
  .attr("width", width)
  .attr("height", height)
  .attr("class", "chart");

// Setting Radius
  var circRadius;
  function crGet() {
    if (width <= 520) {
      circRadius = 4;
    }
    else {
      circRadius = 10;
    }
  }
  crGet();

//Bottom Axis
// Nesting bottom lables by grouping
svg.append("g").attr("class", "xText");
var xText = d3.select(".xText");

function xTextRefresh() {
    xText.attr(
      "transform",
      "translate(" +
        ((width - labelArea) / 2 + labelArea) +
        ", " +
        (height - margin - tPadBot) +
        ")"
    );
  }
  xTextRefresh();

  //Poverty
xText
.append("text")
.attr("y", -26)
.attr("data-name", "poverty")
.attr("data-axis", "x")
.attr("class", "aText active x")
.text("In Poverty (%)");

//Left Axis
//Specifying variable to create more readable  transform attributes
var leftTextX = margin + tPadLeft;
var leftTextY = (height + labelArea) / 2 - labelArea;
 // second lable group for left axis
svg.append("g").attr("class", "yText");
var yText = d3.select(".yText");

// Nesting the group's transform attribute in a function

    yText.attr(
      "transform",
      "translate(" + leftTextX + ", " + leftTextY + ")rotate(-90)"
    );

// Appending

//Healthcare
yText
  .append("text")
  .attr("y", 26)
  .attr("data-name", "healthcare")
  .attr("data-axis", "y")
  .attr("class", "aText inactive y")
  .text("Healthcare (%)");


//Importing data from CVS
D3.csv("data.csv").then(function(data) {
    // Visualizing the data
    visualize(data);
  });

//Creating the visualization 
function visualize(theData) {
 var curX = "poverty";
 var curY = "healthcare";


 // Saving empty variables for the min and max values of x and y.
  
  var xMin;
  var xMax;
  var yMin;
  var yMax;


  //change the min and max for x
  function xMinMax() {
    xMin = d3.min(theData, function(d) {
      return parseFloat(d[curX]) * 0.90;
    });

    xMax = d3.max(theData, function(d) {
        return parseFloat(d|curx) * 1.10;
    });
  
  }

  // b. change the min and max for y
  function yMinMax() {
    // min will grab the smallest datum from the selected column.
    yMin = d3.min(theData, function(d) {
      return parseFloat(d[curY]) * 0.90;
    });

    // .max will grab the largest datum from the selected column.
    yMax = d3.max(theData, function(d) {
      return parseFloat(d[curY]) * 1.10;
    });
  }

  //Scatter Plot 
  xMinMax();
  yMinMax();

  var xScale = d3
    .scaleLinear()
    .domain([xMin, xMax])
    .range([margin + labelArea, width - margin]);
  var yScale = d3
    .scaleLinear()
    .domain([yMin, yMax])
    .range([height - margin - labelArea, margin]);

  // Creating Axis
  var xAxis = d3.axisBottom(xScale);
  var yAxis = d3.axisLeft(yScale);

  //Appending the axes in group elements.
  svg
  .append("g")
  .call(xAxis)
  .attr("class", "xAxis")
  .attr("transform", "translate(0," + (height - margin - labelArea) + ")");
  svg
    .append("g")
    .call(yAxis)
    .attr("class", "yAxis")
    .attr("transform", "translate(" + (margin + labelArea) + ", 0)");

// Using circles, grouping the dots and their lables
    var theCircles = svg.selectAll("g theCircles").data(theData).enter();

  // Appending circles(each row and each state)
  theCircles
    .append("circle")
    .attr("cx", function(d) {
      return xScale(d[curX]);
    })
    .attr("cy", function(d) {
      return yScale(d[curY]);
    })
    .attr("r", circRadius)
    .attr("class", function(d) {
      return "stateCircle " + d.abbr;
    });
}


